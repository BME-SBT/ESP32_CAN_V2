*PADS-LIBRARY-PART-TYPES-V9*

ULN2003ADR SOIC127P600X175-16M I ANA 7 1 0 0 0
TIMESTAMP 2026.01.12.21.10.47
"Mouser Part Number" 595-ULN2003ADR
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Texas-Instruments/ULN2003ADR?qs=D5pVkbrsqqI8WxXD0eSvDA%3D%3D
"Manufacturer_Name" Texas Instruments
"Manufacturer_Part_Number" ULN2003ADR
"Description" Trans Darlington NPN 50V 0.5A SOIC16 Texas Instruments ULN2003ADR, 7-element NPN Darlington Transistor Array, 0.5 A 50 V, 16-Pin SOIC
"Datasheet Link" http://www.ti.com/lit/ds/symlink/uln2003a.pdf
"Geometry.Height" 1.75mm
GATE 1 16 0
ULN2003ADR
1 0 U 1B
2 0 U 2B
3 0 U 3B
4 0 U 4B
5 0 U 5B
6 0 U 6B
7 0 U 7B
8 0 U E
16 0 U 1C
15 0 U 2C
14 0 U 3C
13 0 U 4C
12 0 U 5C
11 0 U 6C
10 0 U 7C
9 0 U COM

*END*
*REMARK* SamacSys ECAD Model
8642/1829388/2.50/16/3/Integrated Circuit
